---
layout: default
breadcrumb: Ouverture
---

# Notre-Dame Providence

<div class="mt-8 grid grid-cols-2 gap-10 text-sm">

<div>

Un collège-lycée à **Enghien-les-Bains**, dans un nord-parisien jeune,
dense, et qui grandit vite.

L'établissement a choisi d'ouvrir ici une formation qui n'existait
nulle part ailleurs, plutôt qu'une filière de plus.

</div>

<div>

<h3>Ce que ça change pour vous</h3>

- Une petite promotion, pas un amphi
- Des locaux et du matériel pensés pour la 3D
- Des enseignants qui vous connaîtront par votre prénom

</div>

</div>

<!--
Ne pas réciter l'histoire de l'établissement : ils viennent d'y entrer, ils la
découvriront. Dire pourquoi NDP a monté CETTE formation, c'est ça qui les concerne.
TODO : une ou deux phrases de ta main sur le projet de l'établissement.
-->

---
layout: default
breadcrumb: Ouverture
---

# ARTFX

<div class="mt-6 text-lg">Animation &middot; VFX &middot; Cinéma &middot; Jeu vidéo</div>

<div class="mt-8 grid grid-cols-2 gap-10 text-sm">

<div>

Une école de création numérique, et un réseau de studios.
C'est le partenaire qui apporte le contexte industriel de votre formation :
les workshops, les intervenants, l'année 3, le demoreel.

</div>

<div>

<h3>La culture qui vient avec</h3>

- On travaille en **workshops**, pas en cours magistraux
- On rend un **projet**, pas une copie
- Ce qui vous suivra, c'est votre **demoreel**

</div>

</div>

<!--
Beaucoup ne connaissent ARTFX que de nom, ou pas du tout. Deux minutes.
Insister sur la culture studio : c'est le vrai choc pour un sortant de lycée.
-->

---
layout: default
breadcrumb: Ouverture
---

# L'équipe

<!--
TODO : photos + noms + rôles, en grille.
Si un directeur prend la parole, c'est ici qu'on lui passe le micro —
et le cold open de la diapo suivante relance la salle juste après.
-->

---
layout: demo
---

<ShaderCanvas src="/shaders/raymarch.frag" :steps="12" height="100%" />

::caption::

Dans deux ans, vous saurez écrire *ça*.

<!--
LE COLD OPEN. 90 secondes, pas plus, et c'est ici que ma prise de parole commence
vraiment — après l'institutionnel, avant l'abstrait.

Ne rien expliquer techniquement. Laisser tourner, laisser le silence travailler,
puis la phrase. Enchaîner directement sur la diapo suivante.

PLAN B : si WebGL2 ne passe pas sur la machine de la salle, le composant affiche
le message d'erreur en clair — prévoir une capture vidéo dans public/heavy/.
-->

---
layout: statement
---

# Le premier BTS mêlant informatique, réseau et simulation 3D

Et vous êtes la première promotion.

<!--
Le mot « première » fait deux choses : il flatte, et il engage. Les deux sont utiles
un jour de rentrée. Enchaîner sans pause.
-->

---
layout: section
breadcrumb: 1 — Le métier a changé
---

# Ce que vous croyez venir apprendre

Et ce que vous allez réellement apprendre
