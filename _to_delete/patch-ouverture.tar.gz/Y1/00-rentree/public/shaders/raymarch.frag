#version 300 es
precision highp float;

// Raymarching : pas de maillage, pas de triangles.
// Une fonction de distance, et pour chaque pixel on avance le long d'un rayon
// jusqu'a toucher la surface. Ce fichier s'execute une fois par pixel.

uniform vec2  u_resolution;
uniform float u_time;
uniform int   u_steps;   // branche sur $clicks : le nombre de pas augmente au clic

out vec4 fragColor;

const vec3 ORANGE = vec3(0.918, 0.314, 0.153);
const vec3 CREAM  = vec3(0.929, 0.933, 0.855);

mat2 rot(float a) { return mat2(cos(a), -sin(a), sin(a), cos(a)); }

float sdSphere(vec3 p, float r) { return length(p) - r; }

float sdBox(vec3 p, vec3 b) {
  vec3 q = abs(p) - b;
  return length(max(q, 0.0)) + min(max(q.x, max(q.y, q.z)), 0.0);
}

float smin(float a, float b, float k) {
  float h = clamp(0.5 + 0.5 * (b - a) / k, 0.0, 1.0);
  return mix(b, a, h) - k * h * (1.0 - h);
}

// La scene : un cube et une sphere fondus l'un dans l'autre.
float map(vec3 p) {
  vec3 q = p;
  q.xz *= rot(u_time * 0.5);
  q.xy *= rot(u_time * 0.31);
  float box = sdBox(q, vec3(0.52));
  float sph = sdSphere(p - vec3(0.0, sin(u_time) * 0.28, 0.0), 0.62);
  return smin(box, sph, 0.22);
}

vec3 normal(vec3 p) {
  vec2 e = vec2(0.0012, 0.0);
  return normalize(vec3(
    map(p + e.xyy) - map(p - e.xyy),
    map(p + e.yxy) - map(p - e.yxy),
    map(p + e.yyx) - map(p - e.yyx)
  ));
}

void main() {
  vec2 uv = (gl_FragCoord.xy * 2.0 - u_resolution) / u_resolution.y;

  vec3 ro = vec3(0.0, 0.0, -3.2);
  vec3 rd = normalize(vec3(uv, 1.7));

  int maxSteps = clamp(6 + u_steps * 10, 6, 96);

  float d = 0.0;
  bool hit = false;
  vec3 p = ro;

  for (int i = 0; i < 96; i++) {
    if (i >= maxSteps) break;
    p = ro + rd * d;
    float s = map(p);
    if (s < 0.0015) { hit = true; break; }
    d += s;
    if (d > 12.0) break;
  }

  vec3 col = vec3(0.0);   // fond noir, raccord avec le layout demo

  if (hit) {
    vec3 n = normal(p);
    vec3 l = normalize(vec3(-0.6, 0.8, -0.7));
    float diff = max(dot(n, l), 0.0);
    float rim  = pow(1.0 - max(dot(n, -rd), 0.0), 2.5);
    float spec = pow(max(dot(reflect(-l, n), -rd), 0.0), 32.0);

    col = ORANGE * (0.18 + 0.82 * diff);
    col += CREAM * rim * 0.45;
    col += vec3(1.0) * spec * 0.5;
  }

  // gamma
  fragColor = vec4(pow(col, vec3(0.4545)), 1.0);
}
