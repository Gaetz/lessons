#version 300 es
precision highp float;

uniform vec2  u_resolution;
uniform float u_time;
uniform int   u_steps;   // pilote par $clicks : le raymarching se construit a l'ecran

out vec4 fragColor;

float sdSphere(vec3 p, float r) { return length(p) - r; }
float sdBox(vec3 p, vec3 b) {
  vec3 q = abs(p) - b;
  return length(max(q, 0.0)) + min(max(q.x, max(q.y, q.z)), 0.0);
}

float map(vec3 p) {
  float t = u_time * 0.6;
  vec3 q = p;
  q.xz = mat2(cos(t), -sin(t), sin(t), cos(t)) * q.xz;
  return min(sdSphere(p - vec3(0.0, sin(t) * 0.2, 0.0), 0.6), sdBox(q, vec3(0.45)));
}

void main() {
  vec2 uv = (gl_FragCoord.xy * 2.0 - u_resolution) / u_resolution.y;
  vec3 ro = vec3(0.0, 0.0, -3.0);
  vec3 rd = normalize(vec3(uv, 1.6));

  int maxSteps = clamp(8 + u_steps * 12, 8, 96);
  float d = 0.0;
  float hit = 0.0;

  for (int i = 0; i < 96; i++) {
    if (i >= maxSteps) break;
    vec3 p = ro + rd * d;
    float s = map(p);
    if (s < 0.001) { hit = 1.0; break; }
    d += s;
    if (d > 12.0) break;
  }

  vec3 bg  = vec3(0.02);
  vec3 col = mix(bg, vec3(0.92, 0.31, 0.15), hit);
  col = mix(col, vec3(0.93, 0.93, 0.85), hit * (1.0 - d / 6.0));
  fragColor = vec4(col, 1.0);
}
