---
layout: default
breadcrumb: 3 — Cinéma et 3D / Points communs
---

# VFX et jeu vidéo : le même problème

<div class="grid grid-cols-3 gap-6 mt-12 text-center">
<div><h2>Générer des images</h2></div>
<div><h2>Maths &amp; code</h2></div>
<div><h2>Technologie</h2></div>
</div>

---
layout: default
breadcrumb: 3 — Cinéma et 3D / Le pipeline
---

# Le vrai métier n'est pas de faire des images

C'est de faire tourner l'usine qui les fait.

<v-clicks>

- Python, USD, outils DCC — Maya, Houdini, Nuke
- La ferme de rendu et son ordonnancement
- Le versioning des assets, la traçabilité des plans
- Les téraoctets, et leur sauvegarde

</v-clicks>

<!--
TODO : un ou deux chiffres qui frappent — heures de rendu par frame,
volume de données d'un long-métrage, taille d'une équipe.
À sourcer avant de les annoncer.
-->

---
layout: split
breadcrumb: 3 — Cinéma et 3D / Temps réel
---

# Le budget de frame

Là où la programmation redevient dure, et non délégable.

<div class="mt-6 text-sm op-70">
Le cinéma peut attendre huit heures pour une image.<br/>
Le temps réel a seize millisecondes.
</div>

::right::

<FrameBudget :steps="$clicks" :fps="60" />

<!--
Le meilleur argument de la journée : il boucle sur la partie 1.
Avancer poste par poste, laisser le dépassement arriver tout seul.
-->

---
layout: default
breadcrumb: 3 — Cinéma et 3D / Temps réel
---

# Ce qu'il y a dans un moteur

<div class="grid grid-cols-3 gap-x-8 gap-y-3 mt-8 text-sm">
<div><b>Boucle de jeu</b><br/><span class="op-60">ordonnancer le temps</span></div>
<div><b>ECS</b><br/><span class="op-60">organiser les données</span></div>
<div><b>Rendu</b><br/><span class="op-60">remplir le framebuffer</span></div>
<div><b>Physique</b><br/><span class="op-60">intégrer, détecter, résoudre</span></div>
<div><b>Audio</b><br/><span class="op-60">mixer sans jamais rater un buffer</span></div>
<div><b>Réseau</b><br/><span class="op-60">mentir juste assez sur l'état du monde</span></div>
</div>

<!-- Un aperçu, pas un cours. Deux minutes maximum. -->

---
layout: default
breadcrumb: 3 — Cinéma et 3D / GPU
---

# Penser en parallèle

<ShaderCanvas src="/shaders/raymarch.frag" :steps="$clicks" height="300px" />

<div class="mt-3 text-xs op-70">
Ce shader s'exécute une fois par pixel. Deux millions de fois par image, soixante fois par seconde.
</div>

<v-click><div class="hidden" /></v-click>
<v-click><div class="hidden" /></v-click>
<v-click><div class="hidden" /></v-click>
<v-click><div class="hidden" /></v-click>

<!--
Avancer au clic : le nombre de pas de raymarching augmente, la forme apparaît.
On montre la construction au lieu de la décrire.
PLAN B : capture vidéo dans public/heavy/ si la machine de la salle n'a pas WebGL2.
-->

---
layout: default
breadcrumb: 3 — Cinéma et 3D / Convergence
---

# Les frontières tombent

<v-clicks>

- Le temps réel entre au cinéma — virtual production, murs LED, Unreal sur le plateau
- L'offline entre dans le jeu — path tracing
- Le génératif entre dans les deux — diffusion, Gaussian splatting, capture

</v-clicks>

<div v-click class="mt-8 text-lg"><b>Ceux qui savent programmer traversent.</b></div>

---
layout: default
breadcrumb: 3 — Cinéma et 3D / Débouchés
---

# Et bien au-delà du divertissement

Automobile, architecture, défense, jumeaux numériques, simulation, XR.

<div class="mt-6 text-sm op-70">Même savoir-faire. Marché beaucoup plus large. C'est ce qui sécurise votre avenir.</div>

---
layout: default
breadcrumb: 3 — Cinéma et 3D / Game design
---

# Un mot sur le game design

<div class="grid grid-cols-2 gap-8 mt-6">

<div>
<h3>Ce que c'est</h3>

- Des systèmes, des boucles
- Une économie, des feedbacks
- De l'équilibrage mesuré

</div>

<div>
<h3>Ce que ce n'est pas</h3>

- « Avoir des idées »

</div>

</div>

<div v-click class="mt-8">
Le programmeur qui comprend le design est celui qui peut <b>prototyper</b>.<br/>
Et c'est le prototype qui décide.
</div>

---
layout: default
breadcrumb: 3 — Cinéma et 3D / Création graphique
---

# Un mot sur la création graphique 3D

Le métier de vos camarades d'ARTFX : modeling, texturing, lookdev, lighting, animation.

<v-clicks>

- Vous écrirez des outils **pour des artistes**
- Un outil écrit sans comprendre le geste de l'artiste ne sert à rien
- La collaboration artiste / programmeur est la compétence rare

</v-clicks>

---
layout: section
breadcrumb: Clôture
---

# À partir de demain
