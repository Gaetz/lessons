---
layout: default
breadcrumb: 1 — Le métier a changé
---

# Trois âges de l'ingénierie logicielle

<div class="grid grid-cols-3 gap-6 mt-8 text-sm">

<div>
<h3>Âge 1</h3>
<p><b>La machine est rare.</b><br/>L'humain est abondant.</p>
<p class="op-60">On optimise le cycle CPU.</p>
</div>

<div>
<h3>Âge 2</h3>
<p><b>L'abstraction est reine.</b><br/>Langages, OS, réseau, cloud.</p>
<p class="op-60">Ce qui coûte : coordonner, intégrer.</p>
</div>

<div>
<h3>Âge 3</h3>
<p><b>Le code se génère.</b><br/>Nous y sommes.</p>
<p class="op-60">Ce qui coûte : savoir ce qu'on veut, savoir si c'est juste.</p>
</div>

</div>

<!--
Ne pas faire de frise historique. Pour chaque âge : ce qui est rare, ce qui est cher.
C'est la seule grille qui compte pour comprendre la suite.
-->

---
layout: split
breadcrumb: 1 — Le métier a changé
---

# Ce que l'IA a fait baisser

<v-clicks>

- Le boilerplate
- Le prototype jetable
- La documentation
- La traduction d'un langage à l'autre
- L'exploration d'une API inconnue

</v-clicks>

::right::

<div v-click="[1, 99]">

# Ce qu'elle n'a pas fait baisser

<v-clicks at="6">

- **La spécification** — savoir ce qu'on veut
- **La vérification** — savoir si c'est juste
- **La performance** — 16,6 ms ne se négocient pas
- **La responsabilité** — quelqu'un signe

</v-clicks>

</div>

<!--
Être honnête et frontal : ils utilisent déjà ces outils. Un discours de déni
me décrédibilise en trente secondes. Le message : « vous les utiliserez ici,
tous les jours, sans culpabilité. La formation vous entraîne à ce que l'outil ne fait pas. »
-->

---
layout: statement
---

# Le junior qui ne sait que prompter n'a pas de plancher

Celui qui sait lire, mesurer et décider en a un.

---
layout: section
breadcrumb: 2 — Le programme
---

# De quoi doit être fait un cursus en 2026 ?
