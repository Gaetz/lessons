---
layout: default
breadcrumb: Ouverture
---

# Notre-Dame Providence

- L'établissement, le territoire
- Ce que ça veut dire d'être ici, à Enghien
- TODO : chiffres clés, historique en une ligne

---
layout: default
breadcrumb: Ouverture
---

# ARTFX

- Écoles de cinéma, VFX, animation, jeu vidéo
- La culture studio : workshops, production, demoreel
- Le réseau d'anciens et les studios partenaires

---
layout: default
breadcrumb: Ouverture
---

# L'équipe de direction

<!-- TODO : photos + noms + rôles.
     Prévoir le cas où l'un des deux directeurs prend la parole ici. -->

---
layout: statement
---

# Le premier BTS mêlant informatique, réseau et simulation 3D

Et vous êtes la première promotion.

---
layout: section
breadcrumb: 1 — Le métier a changé
---

# Ce que vous croyez venir apprendre

Et ce que vous allez réellement apprendre
