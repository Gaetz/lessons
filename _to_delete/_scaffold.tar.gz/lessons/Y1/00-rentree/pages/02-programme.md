---
layout: default
breadcrumb: 2 — Le programme
---

# Trois piliers, et la plupart des cursus n'en enseignent qu'un

<div class="grid grid-cols-3 gap-6 mt-10">

<div><h2>Les systèmes</h2><p class="text-sm">Où ça tourne.</p><p class="mt-3 text-xs op-70">U4 — Support et mise à disposition de services</p></div>
<div><h2>Le code</h2><p class="text-sm">Ce que ça fait.</p><p class="mt-3 text-xs op-70">U5 — Conception et développement d'applications</p></div>
<div><h2>La sécurité</h2><p class="text-sm">Ce qui peut mal tourner.</p><p class="mt-3 text-xs op-70">U6 — Cybersécurité des services informatiques</p></div>

</div>

---
layout: default
breadcrumb: 2 — Le programme
---

# Et le reste n'est pas du remplissage

| | |
|---|---|
| **U1 — Expression, anglais** | Spécifier, documenter, présenter, convaincre. Devenu le cœur du métier, pas la périphérie. |
| **U2 — Mathématiques** | L'algèbre linéaire *est* la 3D. Une matrice 4×4, c'est un objet dans l'espace. |
| **U3 — Culture éco. et juridique** | Droits, contrats, propriété intellectuelle, RGPD. Quotidien en production. |

<!--
C'est le point à défendre explicitement : sinon ils subissent ces heures sans les comprendre.
-->

---
layout: default
breadcrumb: 2 — Le programme
---

# « C'est un BTS, pas une école d'ingénieur »

<!--
Traiter l'objection de front. Ils y ont déjà pensé, ou leurs parents.
Réponse : le contenu, l'exigence, l'année 3 RNCP niveau 6, l'alternance,
la poursuite d'études possible en cycle Bac+5.
TODO : chiffres de poursuite d'études / insertion.
-->

---
layout: default
breadcrumb: 2 — Le programme
---

# Les projets

<div class="grid grid-cols-2 gap-8 mt-6 text-sm">

<div>
<h3>Année 1</h3>

- Jeux 2D en C++ : physique, gameplay, multijoueur, UI
- Contrôleurs alternatifs et lutherie numérique
- Réseau, OS et hacking
- Applications web et bases de données
- Introduction aux logiciels 3D et à la génération d'images

</div>

<div>
<h3>Année 2</h3>

- Jeux 3D, bases de moteurs — Unity, Unreal
- Pipeline de films 3D et logiciels d'effets spéciaux
- Cybersécurité : protection des infrastructures
- IA : deep learning, réseaux de neurones
- Stage en fin de cursus

</div>

</div>

---
layout: default
breadcrumb: 2 — Le programme
---

# Ce qu'on attend de vous

<!--
C'est ici qu'on pose l'exigence : rythme, projets en autonomie, workshops ARTFX,
demoreel. Posture, régularité, curiosité. Ne pas édulcorer.
-->

---
layout: section
breadcrumb: 3 — Cinéma et 3D
---

# L'informatique pour le cinéma et la 3D

Le terrain où tout ce qui précède se joue
